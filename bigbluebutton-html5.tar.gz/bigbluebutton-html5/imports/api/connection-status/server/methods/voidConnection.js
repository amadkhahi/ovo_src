// Round-trip time helper
export default function voidConnection() {
  return 0;
}
