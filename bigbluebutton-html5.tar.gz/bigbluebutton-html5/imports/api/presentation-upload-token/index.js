const PresentationUploadToken = new Mongo.Collection('presentation-upload-token');

export default PresentationUploadToken;
