import { Meteor } from 'meteor/meteor';
import userChangedLocalSettings from './methods/userChangedLocalSettings';

Meteor.methods({
  userChangedLocalSettings,
});
