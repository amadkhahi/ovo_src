import { Meteor } from 'meteor/meteor';

Meteor.methods({
});
