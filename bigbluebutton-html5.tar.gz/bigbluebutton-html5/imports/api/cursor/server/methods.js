import { Meteor } from 'meteor/meteor';
import publishCursorUpdate from './methods/publishCursorUpdate';

Meteor.methods({
  publishCursorUpdate,
});
